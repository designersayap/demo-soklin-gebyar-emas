export const componentDefaults = {
    "background-full-body": {
        image: "",
        mobileImage: ""
    },

    "header-section": {
        title: "Title",
        subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
        titleVisible: true,
        subtitleVisible: true,
        buttonStyle: "primary",
        buttonText: "Label",
        buttonUrl: "",
        buttonVisible: true,
        buttonLinkType: "url",
        buttonId: "",
        secondaryButtonText: "Label",
        secondaryButtonUrl: "",
        secondaryButtonVisible: true,
        secondaryButtonLinkType: "url",
        secondaryButtonId: ""
    },
    "header-group": {
        title: "Title",
        subtitle: "Category",
        titleVisible: true,
        subtitleVisible: true,
        buttonStyle: "primary",
        buttonText: "Label",
        buttonUrl: "",
        buttonVisible: true,
        buttonLinkType: "url",
        buttonId: "",
        secondaryButtonText: "Label",
        secondaryButtonUrl: "",
        secondaryButtonVisible: true,
        secondaryButtonLinkType: "url",
        secondaryButtonId: ""
    },
    "hero-terra-banner": {
        title: "Title",
        subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
        titleVisible: true,
        subtitleVisible: true,
        buttonStyle: "primary",
        buttonText: "Label",
        buttonUrl: "",
        buttonVisible: true,
        buttonLinkType: "url",
        buttonId: "",
        secondaryButtonText: "Label",
        secondaryButtonUrl: "",
        secondaryButtonVisible: true,
        secondaryButtonLinkType: "url",
        secondaryButtonId: "",
        image: "",
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: ""
    },
    "footer-terra": {
        image: "",
        copyrightText: "Copyright © [brand_name] 2026",
        availableAtTitle: "Available At",
        resourcesTitle: "Follow Us",
        socialLinks: [
            { label: '[social-link]', url: '', visible: true, id: '', image: '', imageId: '' },
            { label: '[social-link]', url: '', visible: true, id: '', image: '', imageId: '' },
            { label: '[social-link]', url: '', visible: true, id: '', image: '', imageId: '' }
        ],
        findUsOnLinks: [{
            label: "[marketplace_name]",
            url: "",
            visible: true,
            id: "",
            image: "",
            imageId: "",
            linkType: "url",
            targetDialogId: ""
        },
        {
            label: "[marketplace_name]",
            url: "",
            visible: true,
            id: "",
            image: "",
            imageId: "",
            linkType: "url",
            targetDialogId: ""
        },
        {
            label: "[marketplace_name]",
            url: "",
            visible: true,
            id: "",
            image: "",
            imageId: "",
            linkType: "url",
            targetDialogId: ""
        }
        ],
        resourceLinks: [{
            label: "Terms & Conditions",
            url: "", visible: true,
            id: "",
            linkType: "url",
            targetDialogId: ""
        },
        {
            label: "Privacy Policy",
            url: "", visible: true,
            id: "",
            linkType: "url",
            targetDialogId: ""
        }
        ]
    },
    "feature-image-left": {
        title: "Title",
        subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
        titleVisible: true,
        subtitleVisible: true,
        buttonStyle: "primary",
        buttonText: "Label",
        buttonUrl: "",
        buttonVisible: true,
        buttonLinkType: "url",
        buttonId: "",
        secondaryButtonText: "Label",
        secondaryButtonUrl: "",
        secondaryButtonVisible: true,
        secondaryButtonLinkType: "url",
        secondaryButtonId: "",
        image: "",
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: ""
    },
    "feature-image-right": {
        title: "Title",
        subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
        titleVisible: true,
        subtitleVisible: true,
        buttonStyle: "primary",
        buttonText: "Label",
        buttonUrl: "",
        buttonVisible: true,
        buttonLinkType: "url",
        buttonId: "",
        secondaryButtonText: "Label",
        secondaryButtonUrl: "",
        secondaryButtonVisible: true,
        secondaryButtonLinkType: "url",
        secondaryButtonId: "",
        image: "",
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: ""
    },
    "dialog-item-list": {
        title: "Title",
        description: "Description",

        image: "",
        imageId: "",
        imageVisible: true,
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: "",
        items: Array(8).fill({ label: "Label", image: "", url: "", itemId: "", visible: true })
    },
    "dialog-accordion": {
        title: "Title",
        description: "Description",
        image: "",
        imageId: "",
        imageVisible: true,
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: "",
        items: Array(8).fill({ title: "Accordion Title", content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit." })
    },
    "dialog-form": {
        title: "Title",
        description: "Description",
        image: "",
        imageId: "",
        imageVisible: true,
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: "",
        marketingConsentLabel: "I agree to receive information about exciting offers, product updates, and other information from [brand_name] and other Wings brands.",
        collectionConsentLabel: "I agree to allow Wings to manage my personal data in accordance with the Wings Privacy Policy.",
        nameVisible: true,
        emailVisible: true,
        whatsappVisible: true,
        genderVisible: true,
        dobVisible: true,
        nameFieldId: "name-field",
        emailFieldId: "email-field",
        whatsappFieldId: "whatsapp-field",
        genderFieldId: "gender-field",
        dobFieldId: "dob-field",
        marketingConsentId: "marketing-consent",
        collectionConsentId: "collection-consent"
    },
    "form-personal-data-section": {
        marketingConsentLabel: "I agree to receive information about exciting offers, product updates, and other information from [brand_name] and other Wings brands.",
        collectionConsentLabel: "I agree to allow Wings to manage my personal data in accordance with the Wings Privacy Policy.",
        nameVisible: true,
        emailVisible: true,
        whatsappVisible: true,
        genderVisible: true,
        dobVisible: true,
        marketingConsentVisible: true,
        collectionConsentVisible: true,
        nameFieldId: "name-field",
        emailFieldId: "email-field",
        whatsappFieldId: "whatsapp-field",
        genderFieldId: "gender-field",
        dobFieldId: "dob-field",
        marketingConsentId: "marketing-consent",
        collectionConsentId: "collection-consent"
    },
    "osm-banner": {
        title: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
        buttonText: "Label",
        buttonUrl: "",
        buttonVisible: true,
        buttonLinkType: "url",
        buttonTargetDialogId: "",
        buttonId: "",
        isSticky: true,
        isOverlay: false
    },
    "media-16-9": {
        image: "",
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: "",
        fullWidth: false,
        imageIsPortrait: false,
        imageMobileRatio: ""
    },
    "media-5-4": {
        image: "",
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: "",
        fullWidth: false,
        imageIsPortrait: false,
        imageMobileRatio: ""
    },
    "media-4-3": {
        image: "",
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: "",
        fullWidth: false,
        imageIsPortrait: false,
        imageMobileRatio: ""
    },
    "media-21-9": {
        image: "",
        imageUrl: "",
        imageLinkType: "url",
        imageTargetDialogId: "",
        fullWidth: false,
        imageIsPortrait: false,
        imageMobileRatio: ""
    },
    "media-grid-col-3": {
        images: Array.from({ length: 6 }, (_, i) => ({
            image: "",
            imageUrl: "",
            imageLinkType: "url",
            imageTargetDialogId: "",
            imageIsPortrait: false,
            imageMobileRatio: "",
            visible: true,
            cardId: `image-${i}`
        })),
        fullWidth: false,
        hasFloatingEffect: false
    },
    "media-grid-col-2": {
        images: Array.from({ length: 4 }, (_, i) => ({
            image: "",
            imageUrl: "",
            imageLinkType: "url",
            imageTargetDialogId: "",
            imageIsPortrait: false,
            imageMobileRatio: "",
            visible: true,
            cardId: `image-${i}`
        })),
        fullWidth: false,
        hasFloatingEffect: false
    },
    "navigation-center": {
        logo: "",
        logoVisible: true,
        logoId: "",

        menu1Label: "Menu 1",
        menu1Url: "",
        menu1LinkType: "url",
        menu1TargetDialogId: "",
        menu1Id: "",

        menu2Label: "Menu 2",
        menu2Url: "",
        menu2LinkType: "url",
        menu2TargetDialogId: "",
        menu2Id: "",

        menu3Label: "Menu 3",
        menu3Url: "",
        menu3LinkType: "url",
        menu3TargetDialogId: "",
        menu3Id: "",

        menu4Label: "Menu 4",
        menu4Url: "",
        menu4LinkType: "url",
        menu4TargetDialogId: "",
        menu4Id: "",
        isSticky: true,
        isOverlay: false,
        menuColor: "default"
    },
    "navigation-left": {
        logo: "",
        logoVisible: true,
        logoId: "",

        menu1Label: "Menu 1",
        menu1Url: "",
        menu1LinkType: "url",
        menu1TargetDialogId: "",
        menu1Id: "",

        menu2Label: "Menu 2",
        menu2Url: "",
        menu2LinkType: "url",
        menu2TargetDialogId: "",
        menu2Id: "",

        menu3Label: "Menu 3",
        menu3Url: "",
        menu3LinkType: "url",
        menu3TargetDialogId: "",
        menu3Id: "",

        menu4Label: "Menu 4",
        menu4Url: "",
        menu4LinkType: "url",
        menu4TargetDialogId: "",
        menu4Id: "",
        isSticky: true,
        isOverlay: false,
        menuColor: "default"
    },
    "navigation-right": {
        logo: "",
        logoVisible: true,
        logoId: "",

        menu1Label: "Menu 1",
        menu1Url: "",
        menu1LinkType: "url",
        menu1TargetDialogId: "",
        menu1Id: "",

        menu2Label: "Menu 2",
        menu2Url: "",
        menu2LinkType: "url",
        menu2TargetDialogId: "",
        menu2Id: "",

        menu3Label: "Menu 3",
        menu3Url: "",
        menu3LinkType: "url",
        menu3TargetDialogId: "",
        menu3Id: "",

        menu4Label: "Menu 4",
        menu4Url: "",
        menu4LinkType: "url",
        menu4TargetDialogId: "",
        menu4Id: "",
        isSticky: true,
        isOverlay: false,
        menuColor: "default"
    },
    "testimony-landscape": {
        testimonies: Array(4).fill({
            name: "people name",
            role: "role",
            description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
            image: "",
            imageUrl: "",
            imageLinkType: "url",
            imageTargetDialogId: "",
            avatar: "",
            avatarUrl: "",
            avatarLinkType: "url",
            avatarTargetDialogId: "",
            imageVisible: true,
            avatarVisible: true,
            cardId: "",
            visible: true
        }),
        fullWidth: false,
        autoScroll: true,
        autoScrollEffect: 'slide',
        marqueeDuration: 120
    },
    "testimony-portrait": {
        testimonies: Array(4).fill({
            name: "people name",
            role: "role",
            description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
            image: "",
            imageUrl: "",
            imageLinkType: "url",
            imageTargetDialogId: "",
            avatar: "",
            avatarUrl: "",
            avatarLinkType: "url",
            avatarTargetDialogId: "",
            imageVisible: true,
            avatarVisible: true,
            cardId: "",
            visible: true
        }),
        fullWidth: false,
        autoScroll: true,
        autoScrollEffect: 'slide',
        marqueeDuration: 120
    },
    "scroll-group": {
        image: "", // Desktop Background
        mobileImage: "", // Mobile Background
        imageIsPortrait: false,
        imageMobileRatio: "",
        scrollEffect: "parallax", // 'parallax' | 'sticky'
        components: [] // Nested components
    },
    "spacing-small": {},
    "spacing-medium": {},
    "spacing-large": {},
    "product-carousel-terra": {
        showTabs: true,
        categories: [
            { id: "cat-1", label: "Category 1", visible: true },
            { id: "cat-2", label: "Category 2", visible: true },
            { id: "cat-3", label: "Category 3", visible: true },
            { id: "cat-4", label: "Category 4", visible: true }
        ],
        products: [
            ...Array(4).fill().map((_, i) => ({
                name: "Product 1",
                description: "Description 1",
                image: "", imageUrl: "", imageLinkType: "url", imageTargetDialogId: "", imageVisible: true,
                buttonUrl: "", buttonLinkType: "url", buttonTargetDialogId: "", buttonVisible: true,
                categoryId: "cat-1", cardId: `p1-${i}`, visible: true
            })),
            ...Array(4).fill().map((_, i) => ({
                name: "Product 2",
                description: "Description 2",
                image: "", imageUrl: "", imageLinkType: "url", imageTargetDialogId: "", imageVisible: true,
                buttonUrl: "", buttonLinkType: "url", buttonTargetDialogId: "", buttonVisible: true,
                categoryId: "cat-2", cardId: `p2-${i}`, visible: true
            })),
            ...Array(4).fill().map((_, i) => ({
                name: "Product 3",
                description: "Description 3",
                image: "", imageUrl: "", imageLinkType: "url", imageTargetDialogId: "", imageVisible: true,
                buttonUrl: "", buttonLinkType: "url", buttonTargetDialogId: "", buttonVisible: true,
                categoryId: "cat-3", cardId: `p3-${i}`, visible: true
            })),
            ...Array(4).fill().map((_, i) => ({
                name: "Product 4",
                description: "Description 4",
                image: "", imageUrl: "", imageLinkType: "url", imageTargetDialogId: "", imageVisible: true,
                buttonUrl: "", buttonLinkType: "url", buttonTargetDialogId: "", buttonVisible: true,
                categoryId: "cat-4", cardId: `p4-${i}`, visible: true
            }))
        ]
    },
    "social-bridge-tiktok": {
        videos: Array(4).fill({
            videoUrl: "",
            name: "",
            description: "",
            thumbnailUrl: "",
            fetchedUrl: "",
            cardId: "",
            visible: true
        }),
        fullWidth: false,
        allowAutoplay: true,
    },
    "social-bridge-instagram-feed": {
        items: Array(6).fill({
            title: "Instagram Post Title",
            hashtag: "#hashtag",
            image: "",
            imageId: "",
            cardId: "",
            visible: true,
            url: "",
            linkType: "url",
            targetDialogId: ""
        }),
        autoScroll: true,
        autoScrollEffect: 'slide',
        marqueeDuration: 120
    },
};
